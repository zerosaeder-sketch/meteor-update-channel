import { ChangeEvent, FormEvent, MouseEvent, useEffect, useMemo, useState } from "react";
import { convertFileSrc, invoke } from "@tauri-apps/api/core";

type CoreReply = {
  session_id: string;
  status: string;
  output: string;
  request_id: string;
  trace_id: string;
  memory_count: number;
  memory_status: string;
  model_status: string;
  growth_stage: string;
  growth_progress: number;
  security_state: string;
  grounded: boolean;
  sources: GroundingSource[];
  route: string;
  cognitive_context_items: number;
};

type StatusReply = {
  security_state: string;
  memory_count: number;
  growth_stage: string;
  growth_progress: number;
  calibration_status: string;
  calibration_samples: number;
  next_recalibration_in: number;
  pending_approvals: number;
  model_status: string;
};

type HistoryItem = {
  id: string;
  title: string;
  project_id?: string | null;
  created_at_ms: number;
  updated_at_ms?: number;
};

type ProjectItem = {
  id: string;
  name: string;
  created_at_ms: number;
};

type ProjectExportResult = {
  path: string;
  project_name: string;
  session_count: number;
  message_count: number;
};

type StoredChatMessage = {
  id: string;
  session_id: string;
  role: "user" | "assistant";
  content: string;
  created_at_ms: number;
};

type GroundingSource = {
  index: number;
  title: string;
  url: string;
  domain: string;
  published_at: string;
  source_type: string;
};

type AttachmentInfo = {
  id: string;
  name: string;
  path: string;
  mime: string;
  size_bytes: number;
};

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  sources?: GroundingSource[];
};

type GrowthEvent = {
  id: string;
  event_type: string;
  from_stage: string;
  to_stage: string;
  summary: string;
  details: string[];
  successful_actions: number;
  confidence_percent: number;
  created_at_ms: number;
};


type ImageGenerationResult = {
  image_id: string;
  path: string;
  prompt: string;
  model: string;
  seed: number;
  width: number;
  height: number;
  elapsed_ms: number;
  mode: string;
  profile: string;
  reference_count: number;
  steps: number;
  guidance_scale: number;
};

type ImageGrowthStatus = {
  stage: string;
  progress_percent: number;
  successful_generations: number;
  rated_generations: number;
  average_rating: number;
  quality_points: number;
};

type ImageHistoryItem = {
  image_id: string;
  prompt: string;
  model: string;
  path: string;
  elapsed_ms: number;
  rating?: number | null;
  created_at_ms: number;
};

type ImageCapability = {
  configured: boolean;
  status: string;
  message: string;
  active_model: string;
  loaded: boolean;
  device: string;
  version: string;
  quality_model_installed: boolean;
  capabilities: string[];
};

const EMPTY_IMAGE_CAPABILITY: ImageCapability = {
  configured: false,
  status: "NOT_CONFIGURED",
  message: "이미지 생성 기능 상태를 확인하지 못했습니다.",
  active_model: "",
  loaded: false,
  device: "mps",
  version: "unknown",
  quality_model_installed: false,
  capabilities: []
};

type ImageTask = {
  prompt: string;
  status: "READY" | "NOT_CONFIGURED";
  summary: string;
  defaults: string[];
};


type RouteDecision = {
  intent: "IMAGE_GENERATION" | "VIDEO_GENERATION" | "GROUNDED_RESEARCH" | "ATTACHMENT_ANALYSIS" | "GENERAL_CHAT";
  needs_grounding: boolean;
  needs_cognitive_context: boolean;
  requires_media_engine: boolean;
  confidence: number;
  reason: string;
};

type VideoPlan = {
  mode: string;
  duration_seconds: number;
  aspect_ratio: string;
  motion: string;
  camera: string;
  audio_requested: boolean;
  reference_images: number;
  summary: string;
};


type VideoEngineStatus = {
  configured: boolean;
  reachable: boolean;
  status: string;
  backend_url: string;
  active_model_hint: string;
  local_candidate: string;
  note: string;
};

type VideoGenerationResult = {
  video_path: string;
  elapsed_ms: number;
  backend: string;
  model_hint: string;
  mode: string;
  duration_seconds: number;
  aspect_ratio: string;
  resolution: string;
};

type VerifiedGrowthStatus = {
  calibrated: boolean;
  benchmark_id: string;
  stage: string;
  progress_percent: number;
  score_percent: number | null;
  passed: number;
  total: number;
  factual_accuracy: number | null;
  reasoning_quality: number | null;
  instruction_following: number | null;
  tool_routing: number | null;
  safety_correctness: number | null;
  created_at_ms: number | null;
  improvements: string[];
  note: string;
};

type SkillEvolutionStatus = {
  trusted_registry_path: string;
  staged_dir: string;
  auto_stage_enabled: boolean;
  note: string;
};


type TrustedUpdateStatus = {
  inbox_dir: string;
  staging_dir: string;
  snapshots_dir: string;
  pending_packages: number;
  policy: string;
};

type TrustedUpdateProposal = {
  approval_id: string;
  package_path: string;
  stage_dir: string;
  update_id: string;
  version: string;
  title: string;
  risk_level: string;
  external_transfer: boolean;
  reversible: boolean;
  permissions: string[];
  changes: string[];
  verified_files: number;
  payload_app_path: string;
};

type PreferenceSummary = {
  key: string;
  label: string;
  category: string;
  confidence: number;
  evidence_count: number;
};

type CognitiveStatus = {
  episode_count: number;
  preference_count: number;
  imported_conversations: number;
  imported_messages: number;
  media_feedback_count: number;
  top_preferences: PreferenceSummary[];
};

type ImportReport = {
  import_id: string;
  conversations_seen: number;
  messages_seen: number;
  episodes_created: number;
  preferences_updated: number;
  skipped_sensitive: number;
  skipped_low_confidence: number;
};

type ApprovalProposal = {
  approval_id: string;
  action: string;
  target: string;
  summary: string;
  risk_level: "L0" | "L1" | "L2" | "L3";
  external_transfer: boolean;
  reversible: boolean;
};

type ToolResult = {
  success: boolean;
  summary: string;
  content?: string | null;
};



type NarrativeLibraryItem = {
  work_id: string;
  title: string;
  author?: string | null;
  corpus_tier: string;
  local_only: boolean;
  raw_content_stored: boolean;
};

type NarrativeStructureStatus = {
  chapter_count: number;
  scene_count: number;
  character_count: number;
  event_count: number;
  foreshadow_count: number;
  payoff_count: number;
  stage: string;
};

type NarrativeDocumentIngestReceipt = {
  ingest: {
    work_id: string;
    title: string;
    corpus_tier: string;
    local_only: boolean;
    segmentation: {
      chapter_count: number;
      scene_count: number;
      character_count: number;
    };
  };
  extraction_kind: string;
  extraction_engine: string;
  extracted_units: number;
  original_stored_path: string;
  warnings: string[];
};


type RemoteUpdateStatus = {
  configured: boolean;
  current_version: string;
  manifest_url?: string | null;
  auto_check: boolean;
  auto_download: boolean;
  apply_requires_approval: boolean;
  signature_required: boolean;
  signing_identity: string;
  allowed_hosts: string[];
  publisher_key_ready: boolean;
};
type RemoteUpdateCheck = {
  configured: boolean;
  current_version: string;
  remote_version?: string | null;
  update_available: boolean;
  update_id?: string | null;
  title?: string | null;
  published_at?: string | null;
  signature_verified: boolean;
  notes: string[];
  message: string;
};
type RemoteUpdateApply = {
  status: string;
  from_version: string;
  to_version?: string | null;
  update_id?: string | null;
  title?: string | null;
  signature_verified: boolean;
  bundle_verified: boolean;
  autopilot_exit_code?: number | null;
  message: string;
};

type RightTab = "Updates" | "Library" | "Workspace" | "Images" | "Browser" | "Files" | "Context" | "Growth" | "Models" | "Security";
type HistoryActionMode = "rename" | "move" | "delete" | null;

type ContextMenuState = {
  x: number;
  y: number;
  item: HistoryItem;
} | null;

const growthStages = [
  { name: "사원", models: "Claude Haiku 5.5 / GPT-5.6 Luna" },
  { name: "주임", models: "GPT-5.6 Terra" },
  { name: "대리", models: "Claude Sonnet 5.5 / GPT-5.6 Sol" },
  { name: "과장", models: "GPT-5.6 Sol Pro" },
  { name: "차장", models: "Claude Opus 5.5 / Claude Fable 5.1" },
  { name: "부장", models: "GPT-6 Luna" },
  { name: "상무", models: "GPT-6 Sol" },
  { name: "전무", models: "GPT-6 Pro (GPT-6 Astra)" },
  { name: "부사장", models: "Reserved" },
  { name: "사장", models: "Reserved" },
  { name: "회장", models: "Reserved" }
];

function isImageGenerationRequest(text: string) {
  const normalized = text.trim().toLowerCase();

  const imageNoun = /(이미지|그림|사진|일러스트|일러스트레이션|포스터|로고|배너|썸네일|캐릭터|콘셉트 아트|컨셉 아트|image|picture|photo|illustration|poster|logo|banner|thumbnail|artwork)/i;
  const creationVerb = /(만들|생성|그려|제작|렌더|디자인|바꿔|변환|편집|수정|create|generate|draw|render|design|make|edit|transform)/i;

  if (imageNoun.test(normalized) && creationVerb.test(normalized)) {
    return true;
  }

  return [
    "그려줘", "그려 줘", "이미지화", "사진처럼", "visualize this",
    "make this into an image", "turn this into an image"
  ].some((keyword) => normalized.includes(keyword));
}

function buildImageTask(text: string, capability: ImageCapability | null): ImageTask {
  const defaults = [
    "비율: 1:1 (별도 지정이 있으면 사용자 지시 우선)",
    "품질: 일반 고품질",
    "세부 설정이 빠졌으면 METEOR가 자연스러운 기본값 적용"
  ];

  if (!capability?.configured) {
    return {
      prompt: text,
      status: "NOT_CONFIGURED",
      summary: "이미지 요청은 한 번에 정리했지만 실제 이미지 생성 엔진이 아직 연결되어 있지 않습니다.",
      defaults
    };
  }

  return {
    prompt: text,
    status: "READY",
    summary: "이미지 생성 엔진이 준비되었습니다. 요청은 텍스트 모델이 아니라 전용 이미지 엔진으로 전달됩니다.",
    defaults
  };
}



function chooseImageMode(text: string, referenceCount: number): "FAST" | "QUALITY" | "EDIT" | "REFERENCE" {
  const lower = text.toLowerCase();
  if (/(최고\s*품질|최대한\s*고품질|고품질|quality|max quality|high quality)/i.test(lower)) {
    return "QUALITY";
  }
  if (referenceCount > 0) {
    if (/(편집|수정|바꿔|지워|제거|교체|edit|replace|remove|change)/i.test(lower)) {
      return "EDIT";
    }
    return "REFERENCE";
  }
  return "FAST";
}

function extractUrls(text: string) {
  const matches = text.match(/https?:\/\/[^\s<>"']+/g) ?? [];
  return Array.from(new Set(matches));
}

function looksFresh(text: string) {
  const lower = text.toLowerCase();
  return [
    "오늘", "지금", "현재", "최근", "최신", "뉴스", "속보", "이번주",
    "이번 주", "이번달", "이번 달", "요즘", "실시간", "현황", "동향",
    "today", "latest", "recent", "news", "breaking", "current", "right now"
  ].some((term) => lower.includes(term));
}

export default function App() {
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<AttachmentInfo[]>([]);
  const [droppedLinks, setDroppedLinks] = useState<string[]>([]);
  const [webMode, setWebMode] = useState<"AUTO" | "ON">("AUTO");
  const [dragActive, setDragActive] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "METEOR가 준비되었습니다." }
  ]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [reply, setReply] = useState<CoreReply | null>(null);
  const [status, setStatus] = useState<StatusReply | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [projectCreateOpen, setProjectCreateOpen] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [projectMenu, setProjectMenu] = useState<{ x: number; y: number; project: ProjectItem } | null>(null);
  const [projectDeleteTarget, setProjectDeleteTarget] = useState<ProjectItem | null>(null);
  const [projectActionBusy, setProjectActionBusy] = useState(false);

  const [contextMenu, setContextMenu] = useState<ContextMenuState>(null);
  const [historyActionMode, setHistoryActionMode] = useState<HistoryActionMode>(null);
  const [historyActionItem, setHistoryActionItem] = useState<HistoryItem | null>(null);
  const [historyActionValue, setHistoryActionValue] = useState("");
  const [historyActionBusy, setHistoryActionBusy] = useState(false);

  const [busy, setBusy] = useState(false);
  const [stopping, setStopping] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  const [rightTab, setRightTab] = useState<RightTab>("Workspace");
  const [toolOutput, setToolOutput] = useState("통합 도구 준비 완료.");
  const [workspaceNotice, setWorkspaceNotice] = useState("현재 실행 중인 별도 작업이 없습니다.");
  const [imageCapability, setImageCapability] = useState<ImageCapability | null>(null);
  const [imageTask, setImageTask] = useState<ImageTask | null>(null);
  const [imageBusy, setImageBusy] = useState(false);
  const [imageElapsed, setImageElapsed] = useState(0);
  const [lastImage, setLastImage] = useState<ImageGenerationResult | null>(null);
  const [imageGrowth, setImageGrowth] = useState<ImageGrowthStatus | null>(null);
  const [imageHistory, setImageHistory] = useState<ImageHistoryItem[]>([]);

  const [cognitiveStatus, setCognitiveStatus] = useState<CognitiveStatus | null>(null);
  const [cognitiveImportBusy, setCognitiveImportBusy] = useState(false);
  const [lastImportReport, setLastImportReport] = useState<ImportReport | null>(null);
  const [videoPlan, setVideoPlan] = useState<VideoPlan | null>(null);
  const [videoStatus, setVideoStatus] = useState<VideoEngineStatus | null>(null);
  const [videoBusy, setVideoBusy] = useState(false);
  const [lastVideo, setLastVideo] = useState<VideoGenerationResult | null>(null);
  const [lastVideoPrompt, setLastVideoPrompt] = useState("");
  const [verifiedGrowth, setVerifiedGrowth] = useState<VerifiedGrowthStatus | null>(null);
  const [skillEvolution, setSkillEvolution] = useState<SkillEvolutionStatus | null>(null);
  const [updateStatus, setUpdateStatus] = useState<TrustedUpdateStatus | null>(null);
  const [updateProposal, setUpdateProposal] = useState<TrustedUpdateProposal | null>(null);
  const [updateBusy, setUpdateBusy] = useState(false);
  const [lastRoute, setLastRoute] = useState<RouteDecision | null>(null);

  const [growthHistory, setGrowthHistory] = useState<GrowthEvent[]>([]);
  const [selectedGrowthEvent, setSelectedGrowthEvent] = useState<GrowthEvent | null>(null);

  const [filePath, setFilePath] = useState("notes/demo.txt");
  const [fileContent, setFileContent] = useState("METEOR personal workspace");
  const [url, setUrl] = useState("https://example.com");
  const [approval, setApproval] = useState<ApprovalProposal | null>(null);

const [remoteUpdateStatus, setRemoteUpdateStatus] = useState<RemoteUpdateStatus | null>(null);
const [remoteUpdateCheck, setRemoteUpdateCheck] = useState<RemoteUpdateCheck | null>(null);
const [remoteUpdateBusy, setRemoteUpdateBusy] = useState(false);
const [remoteUpdateNotice, setRemoteUpdateNotice] = useState("Signed Update Channel 상태를 확인할 수 있습니다.");

const [narrativeLibrary, setNarrativeLibrary] = useState<NarrativeLibraryItem[]>([]);
const [narrativeStructure, setNarrativeStructure] = useState<NarrativeStructureStatus | null>(null);
const [narrativeImportBusy, setNarrativeImportBusy] = useState(false);
const [narrativeNotice, setNarrativeNotice] = useState(
  "작품과 연구자료는 Rights Gate를 통과한 뒤 로컬 Narrative Library에 저장됩니다."
);




async function refreshRemoteUpdateStatus() {
  try {
    setRemoteUpdateStatus(await invoke<RemoteUpdateStatus>("get_remote_update_channel_status"));
  } catch (error) {
    setRemoteUpdateNotice(`Update Channel 상태 확인 실패: ${String(error)}`);
  }
}
async function checkRemoteUpdate() {
  if (remoteUpdateBusy) return;
  setRemoteUpdateBusy(true);
  setRemoteUpdateNotice("서명된 업데이트 채널을 확인 중입니다.");
  try {
    const result = await invoke<RemoteUpdateCheck>("check_remote_update_channel");
    setRemoteUpdateCheck(result);
    setRemoteUpdateNotice(result.message);
    await refreshRemoteUpdateStatus();
  } catch (error) {
    setRemoteUpdateNotice(`업데이트 확인 실패: ${String(error)}`);
  } finally { setRemoteUpdateBusy(false); }
}
async function applyRemoteUpdate() {
  if (remoteUpdateBusy) return;
  setRemoteUpdateBusy(true);
  setRemoteUpdateNotice("업데이트를 다운로드·검증하고 Autopilot으로 적용 중입니다.");
  try {
    const result = await invoke<RemoteUpdateApply>("apply_remote_update_channel");
    setRemoteUpdateNotice(result.message);
    await refreshRemoteUpdateStatus();
  } catch (error) {
    setRemoteUpdateNotice(`업데이트 적용 실패: ${String(error)}`);
  } finally { setRemoteUpdateBusy(false); }
}

async function refreshNarrativeLibrary() {
  try {
    const [items, structure] = await Promise.all([
      invoke<NarrativeLibraryItem[]>("get_narrative_library"),
      invoke<NarrativeStructureStatus>("get_narrative_structure_status")
    ]);
    setNarrativeLibrary(items);
    setNarrativeStructure(structure);
  } catch (error) {
    setNarrativeNotice(`Narrative Library 조회 실패: ${String(error)}`);
  }
}

async function importNarrativeDocument(corpusKind: "OWNED" | "PERSONAL_RESEARCH") {
  if (narrativeImportBusy) return;
  setNarrativeImportBusy(true);
  setNarrativeNotice(
    corpusKind === "OWNED"
      ? "내 작품을 로컬 Production Corpus에 등록 중입니다."
      : "개인 연구자료를 LOCAL ONLY Vault에 등록 중입니다."
  );

  try {
    const result = await invoke<NarrativeDocumentIngestReceipt>(
      "choose_and_import_narrative_document",
      { corpusKind }
    );
    const localLabel = result.ingest.local_only ? " · LOCAL ONLY" : "";
    setNarrativeNotice(
      `${result.ingest.title} 등록 완료 · ${result.extraction_kind} · ` +
      `${result.ingest.segmentation.chapter_count}장 / ${result.ingest.segmentation.scene_count}장면${localLabel}`
    );
    await refreshNarrativeLibrary();
  } catch (error) {
    const message = String(error);
    if (!message.includes("취소")) {
      setNarrativeNotice(`자료 추가 실패: ${message}`);
    }
  } finally {
    setNarrativeImportBusy(false);
  }
}

  async function refreshStatus() {
    try {
      setStatus(await invoke<StatusReply>("get_system_status"));
    } catch (error) {
      setToolOutput(`상태 조회 실패: ${String(error)}`);
    }
  }

  async function refreshProjects() {
    try {
      setProjects(await invoke<ProjectItem[]>("list_projects"));
    } catch (error) {
      setProjects([]);
      setToolOutput(`프로젝트 조회 실패: ${String(error)}`);
    }
  }

  async function refreshHistory(projectId: string | null = selectedProjectId) {
    try {
      setHistory(await invoke<HistoryItem[]>("list_chat_sessions", {
        limit: 100,
        projectId
      }));
    } catch (error) {
      setHistory([]);
      setToolOutput(`히스토리 조회 실패: ${String(error)}`);
    }
  }

  async function refreshGrowthHistory() {
    try {
      setGrowthHistory(await invoke<GrowthEvent[]>("get_growth_history", { limit: 30 }));
    } catch (error) {
      setGrowthHistory([]);
      setToolOutput(`성장 히스토리 조회 실패: ${String(error)}`);
    }
  }

  async function refreshImageGrowth() {
    try {
      const [growth, images] = await Promise.all([
        invoke<ImageGrowthStatus>("get_image_growth_status"),
        invoke<ImageHistoryItem[]>("get_image_history", { limit: 20 })
      ]);
      setImageGrowth(growth);
      setImageHistory(images);
    } catch {
      setImageGrowth(null);
      setImageHistory([]);
    }
  }

  async function refreshImageCapability() {
    try {
      setImageCapability(await invoke<ImageCapability>("get_image_generation_status"));
    } catch {
      setImageCapability({
        configured: false,
        status: "NOT_CONFIGURED",
        message: "이미지 생성 기능 상태를 확인하지 못했습니다.",
        active_model: "",
        loaded: false,
        device: "mps",
        version: "unknown",
        quality_model_installed: false,
        capabilities: []
      });
    }
  }


async function refreshCognitiveStatus() {
  try {
    setCognitiveStatus(await invoke<CognitiveStatus>("get_cognitive_learning_status"));
  } catch {
    setCognitiveStatus(null);
  }
}


async function refreshVideoStatus() {
  try {
    setVideoStatus(await invoke<VideoEngineStatus>("get_video_generation_status"));
  } catch {
    setVideoStatus({
      configured: false,
      reachable: false,
      status: "NOT_CONFIGURED",
      backend_url: "http://127.0.0.1:8000",
      active_model_hint: "none",
      local_candidate: "LTX 2.5 Fast",
      note: "LTX Desktop 상태를 확인하지 못했습니다."
    });
  }
}

async function refreshVerifiedGrowth() {
  try {
    setVerifiedGrowth(await invoke<VerifiedGrowthStatus>("get_verified_growth_status"));
  } catch {
    setVerifiedGrowth(null);
  }
}

async function refreshSkillEvolution() {
  try {
    setSkillEvolution(await invoke<SkillEvolutionStatus>("get_skill_evolution_status"));
  } catch {
    setSkillEvolution(null);
  }
}


async function refreshUpdateStatus() {
  try {
    setUpdateStatus(await invoke<TrustedUpdateStatus>("get_trusted_update_status"));
  } catch {
    setUpdateStatus(null);
  }
}

async function openUpdateInbox() {
  try {
    await invoke("open_trusted_update_inbox");
    setWorkspaceNotice("업데이트 Inbox를 열었습니다. METEOR 업데이트 ZIP을 이 폴더에 넣은 뒤 후보 검색을 누르세요.");
  } catch (error) {
    setWorkspaceNotice(`업데이트 Inbox 열기 실패: ${String(error)}`);
  }
}

async function scanUpdateInbox() {
  if (updateBusy) return;
  setUpdateBusy(true);
  try {
    const proposal = await invoke<TrustedUpdateProposal | null>("scan_trusted_update_inbox");
    setUpdateProposal(proposal);
    await refreshUpdateStatus();
    if (proposal) {
      setWorkspaceNotice(`업데이트 후보 ${proposal.version} 검증 완료 · 사용자 승인 대기`);
      setRightTab("Models");
    } else {
      setWorkspaceNotice("검증할 업데이트 ZIP이 Inbox에 없습니다.");
    }
  } catch (error) {
    setUpdateProposal(null);
    setWorkspaceNotice(`업데이트 후보 검사 실패: ${String(error)}`);
  } finally {
    setUpdateBusy(false);
  }
}

async function approveTrustedUpdate() {
  if (!updateProposal || updateBusy) return;
  setUpdateBusy(true);
  try {
    const message = await invoke<string>("approve_trusted_update", {
      approvalId: updateProposal.approval_id
    });
    setWorkspaceNotice(message);
  } catch (error) {
    setWorkspaceNotice(`업데이트 승인/설치 실패: ${String(error)}`);
    setUpdateBusy(false);
  }
}

async function rateVideo(rating: number) {
  if (!lastVideo || !lastVideoPrompt) return;
  try {
    await invoke("rate_video_result", {
      prompt: lastVideoPrompt,
      rating,
      note: null
    });
    setWorkspaceNotice(`영상 평가 ${rating}/5가 개인 영상 선호 학습에 반영되었습니다.`);
    await refreshCognitiveStatus();
  } catch (error) {
    setWorkspaceNotice(`영상 평가 저장 실패: ${String(error)}`);
  }
}

async function importChatGptHistory(event: ChangeEvent<HTMLInputElement>) {
  const file = event.target.files?.[0];
  event.target.value = "";
  if (!file || cognitiveImportBusy) return;

  setCognitiveImportBusy(true);
  setWorkspaceNotice(`ChatGPT 대화 내보내기 분석 중 · ${file.name}`);

  try {
    const data = await file.text();
    const report = await invoke<ImportReport>("import_chatgpt_history_json", { data });
    setLastImportReport(report);
    setWorkspaceNotice(
      `인지 학습 가져오기 완료 · 대화 ${report.conversations_seen}개 · 에피소드 ${report.episodes_created}개`
    );
    await refreshCognitiveStatus();
    setRightTab("Context");
  } catch (error) {
    setWorkspaceNotice(`ChatGPT 대화 가져오기 실패: ${String(error)}`);
    setToolOutput(`인지 학습 가져오기 실패: ${String(error)}`);
  } finally {
    setCognitiveImportBusy(false);
  }
}

  useEffect(() => {
    void refreshStatus();
    void refreshProjects();
    void refreshGrowthHistory();
    void refreshImageCapability();
    void refreshImageGrowth();
    void refreshCognitiveStatus();
    void refreshVideoStatus();
    void refreshVerifiedGrowth();
    void refreshSkillEvolution();
    void refreshUpdateStatus();
    void refreshRemoteUpdateStatus();
    void checkRemoteUpdate();

    const timer = window.setInterval(() => {
      void refreshStatus();
    }, 15000);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    void refreshHistory(selectedProjectId);
  }, [selectedProjectId]);

  useEffect(() => {
    if (rightTab === "Updates") {
      void refreshRemoteUpdateStatus();
    }
    if (rightTab === "Library") {
      void refreshNarrativeLibrary();
    }
    if (rightTab === "Growth") {
      void refreshGrowthHistory();
      void refreshVerifiedGrowth();
    }
    if (rightTab === "Context") {
      void refreshCognitiveStatus();
    }
    if (rightTab === "Models") {
      void refreshVideoStatus();
      void refreshSkillEvolution();
      void refreshUpdateStatus();
    }
  }, [rightTab]);

  useEffect(() => {
    if (!imageBusy) {
      setImageElapsed(0);
      return;
    }
    const started = Date.now();
    const timer = window.setInterval(() => {
      setImageElapsed(Math.floor((Date.now() - started) / 1000));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [imageBusy]);

  useEffect(() => {
    if (!busy) {
      setElapsed(0);
      return;
    }
    const started = Date.now();
    const timer = window.setInterval(() => {
      setElapsed(Math.floor((Date.now() - started) / 1000));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [busy]);

  useEffect(() => {
    const close = () => {
      setContextMenu(null);
      setProjectMenu(null);
    };
    window.addEventListener("click", close);
    return () => window.removeEventListener("click", close);
  }, []);

  async function addImageFiles(files: FileList | File[]) {
    const list = Array.from(files).filter((file) => file.type.startsWith("image/"));
    const slots = Math.max(0, 4 - attachments.length);

    for (const file of list.slice(0, slots)) {
      if (file.size > 20 * 1024 * 1024) {
        setWorkspaceNotice(`${file.name}: 20MB를 초과해 첨부하지 않았습니다.`);
        continue;
      }

      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(file);
      });

      try {
        const saved = await invoke<AttachmentInfo>("save_attachment_data_url", {
          name: file.name,
          mime: file.type,
          dataUrl
        });
        setAttachments((current) => [...current, saved].slice(0, 4));
      } catch (error) {
        setWorkspaceNotice(`이미지 첨부 실패: ${String(error)}`);
      }
    }
  }

  function handleDrop(event: React.DragEvent<HTMLFormElement>) {
    event.preventDefault();
    setDragActive(false);

    if (event.dataTransfer.files.length > 0) {
      void addImageFiles(event.dataTransfer.files);
      return;
    }

    const uriList = event.dataTransfer.getData("text/uri-list");
    const plain = event.dataTransfer.getData("text/plain");
    const urls = extractUrls(uriList || plain);

    if (urls.length > 0) {
      setDroppedLinks((current) => Array.from(new Set([...current, ...urls])).slice(0, 6));
      setWorkspaceNotice(`링크 ${urls.length}개를 채팅 컨텍스트에 추가했습니다.`);
    }
  }

  function handlePaste(event: React.ClipboardEvent<HTMLInputElement>) {
    const imageFiles = Array.from(event.clipboardData.files).filter((file) => file.type.startsWith("image/"));
    if (imageFiles.length > 0) {
      event.preventDefault();
      void addImageFiles(imageFiles);
    }
  }

  function removeAttachment(id: string) {
    setAttachments((current) => current.filter((item) => item.id !== id));
  }

  function removeDroppedLink(url: string) {
    setDroppedLinks((current) => current.filter((item) => item !== url));
  }


async function submit(event: FormEvent) {
  event.preventDefault();
  const text = input.trim();
  if (!text || busy || imageBusy || videoBusy) return;

  const sessionId = currentSessionId ?? crypto.randomUUID();
  if (!currentSessionId) setCurrentSessionId(sessionId);

  const userDisplay = [
    text,
    ...attachments.map((item) => `📎 ${item.name}`),
    ...droppedLinks.map((url) => `🔗 ${url}`)
  ].join("\n");
  setMessages((current) => [...current, { role: "user", content: userDisplay }]);
  setInput("");

  let route: RouteDecision;
  try {
    route = await invoke<RouteDecision>("classify_request", {
      text,
      attachmentCount: attachments.length,
      forceWeb: webMode === "ON"
    });
  } catch {
    route = {
      intent: isImageGenerationRequest(text) ? "IMAGE_GENERATION" : "GENERAL_CHAT",
      needs_grounding: looksFresh(text) || webMode === "ON",
      needs_cognitive_context: true,
      requires_media_engine: false,
      confidence: 0.5,
      reason: "frontend fallback"
    };
  }

  setLastRoute(route);

  if (route.intent === "IMAGE_GENERATION") {
    let currentImageCapability = imageCapability;

    try {
      currentImageCapability = await invoke<ImageCapability>("get_image_generation_status");
      setImageCapability(currentImageCapability);
    } catch {
      currentImageCapability = imageCapability;
    }

    const task = buildImageTask(text, currentImageCapability);
    setImageTask(task);
    setVideoPlan(null);
    setRightTab("Workspace");

    if (!currentImageCapability?.configured) {
      const response =
        "이미지 생성 요청으로 인식했습니다. 현재 전용 이미지 엔진이 준비되지 않아 생성은 시작하지 않았습니다. SETUP_IMAGE_ENGINE.command로 FLUX 엔진을 준비하면 같은 요청이 텍스트 모델이 아니라 이미지 엔진으로 바로 전달됩니다.";
      setMessages((current) => [...current, { role: "assistant", content: response }]);
      setWorkspaceNotice(response);
      await invoke("record_media_turn", {
        sessionId,
        userText: text,
        assistantText: response,
        projectId: selectedProjectId
      }).catch(() => undefined);
      await refreshHistory(selectedProjectId);
      return;
    }

    setImageBusy(true);
    setWorkspaceNotice("이미지 전용 엔진으로 생성 중입니다.");

    try {
      const imageMode = chooseImageMode(text, attachments.length);
      const generated = await invoke<ImageGenerationResult>("generate_image", {
        prompt: text,
        width: 1024,
        height: 1024,
        mode: imageMode,
        referencePaths: attachments.map((item) => item.path)
      });
      setLastImage(generated);
      const response =
        `이미지를 생성했습니다. ${generated.mode} · ${generated.profile} · ` +
        `${generated.reference_count > 0 ? `참조 ${generated.reference_count}장 · ` : ""}` +
        `${(generated.elapsed_ms / 1000).toFixed(1)}초`;
      setMessages((current) => [...current, { role: "assistant", content: response }]);
      setWorkspaceNotice("이미지 생성 완료 · 결과 평가가 개인 이미지 선호 학습에 반영됩니다.");
      setAttachments([]);
      await invoke("record_media_turn", {
        sessionId,
        userText: text,
        assistantText: response,
        projectId: selectedProjectId
      }).catch(() => undefined);
      await Promise.all([
        refreshImageCapability(),
        refreshImageGrowth(),
        refreshCognitiveStatus(),
        refreshHistory(selectedProjectId),
        refreshStatus()
      ]);
    } catch (error) {
      const response = `이미지 생성 실패: ${String(error)}`;
      setMessages((current) => [...current, { role: "assistant", content: response }]);
      setWorkspaceNotice(response);
      await invoke("record_media_turn", {
        sessionId,
        userText: text,
        assistantText: response,
        projectId: selectedProjectId
      }).catch(() => undefined);
    } finally {
      setImageBusy(false);
    }
    return;
  }


if (route.intent === "VIDEO_GENERATION") {
  setVideoBusy(true);
  setRightTab("Workspace");
  setImageTask(null);

  try {
    const plan = await invoke<VideoPlan>("structure_video_request", {
      text,
      imagePaths: attachments.map((item) => item.path)
    });
    setVideoPlan(plan);
    setLastVideoPrompt(text);

    const status = await invoke<VideoEngineStatus>("get_video_generation_status");
    setVideoStatus(status);

    if (!status.reachable || status.status !== "HEALTHY") {
      const response =
        "영상 생성 요청으로 인식했습니다. 현재 LTX 로컬 영상 엔진이 준비되지 않아 실제 생성은 시작하지 않았습니다. " +
        "SETUP_LTX_VIDEO_RUNTIME.command를 실행하고 LTX Desktop에서 모델 라이선스 동의/다운로드를 완료한 뒤 다시 요청하면 됩니다.";
      setMessages((current) => [...current, { role: "assistant", content: response }]);
      setWorkspaceNotice(`Video Runtime · ${status.status}`);
      await invoke("record_media_turn", {
        sessionId,
        userText: text,
        assistantText: response,
        projectId: selectedProjectId
      }).catch(() => undefined);
      return;
    }

    setWorkspaceNotice(
      `LTX 영상 생성 중 · ${plan.mode} · ${plan.duration_seconds}초 · ${plan.aspect_ratio}`
    );

    const generated = await invoke<VideoGenerationResult>("generate_video", {
      prompt: text,
      imagePaths: attachments.map((item) => item.path),
      durationSeconds: plan.duration_seconds,
      aspectRatio: plan.aspect_ratio,
      resolution: "540p"
    });

    setLastVideo(generated);
    const response =
      `영상을 생성했습니다. ${generated.mode} · ${generated.duration_seconds}초 · ` +
      `${generated.resolution} · ${(generated.elapsed_ms / 1000).toFixed(1)}초`;
    setMessages((current) => [...current, { role: "assistant", content: response }]);
    setWorkspaceNotice("영상 생성 완료 · 결과 평가가 Video Preference 학습에 반영됩니다.");

    await invoke("record_media_turn", {
      sessionId,
      userText: text,
      assistantText: response,
      projectId: selectedProjectId
    }).catch(() => undefined);

    setAttachments([]);
    setDroppedLinks([]);
    await Promise.all([
      refreshVideoStatus(),
      refreshCognitiveStatus(),
      refreshHistory(selectedProjectId)
    ]);
  } catch (error) {
    const response = `영상 생성 실패: ${String(error)}`;
    setMessages((current) => [...current, { role: "assistant", content: response }]);
    setWorkspaceNotice(response);
  } finally {
    setVideoBusy(false);
  }
  return;
}

  setBusy(true);
  setStopping(false);
  setVideoPlan(null);
  setWorkspaceNotice(
    route.intent === "GROUNDED_RESEARCH"
      ? "최신 웹 근거를 확인한 뒤 응답합니다."
      : "관련 프로젝트 기억과 인지 학습 컨텍스트를 선별해 응답합니다."
  );

  try {
    const inlineLinks = extractUrls(text);
    const links = Array.from(new Set([...droppedLinks, ...inlineLinks]));
    const forceWeb = webMode === "ON";

    const result = await invoke<CoreReply>("submit_smart_request", {
      text,
      sessionId,
      imagePaths: attachments.map((item) => item.path),
      links,
      forceWeb,
      projectId: selectedProjectId
    });
    setReply(result);
    setCurrentSessionId(result.session_id);
    setMessages((current) => [...current, {
      role: "assistant",
      content: result.output,
      sources: result.sources
    }]);

    if (result.grounded) {
      setWorkspaceNotice(`웹 근거 ${result.sources.length}개 · 인지 컨텍스트 ${result.cognitive_context_items}개를 사용했습니다.`);
    } else if (result.cognitive_context_items > 0) {
      setWorkspaceNotice(`관련 인지 컨텍스트 ${result.cognitive_context_items}개를 선별해 응답했습니다.`);
    } else if (attachments.length > 0) {
      setWorkspaceNotice(`첨부 이미지 ${attachments.length}개를 로컬 멀티모달 입력으로 처리했습니다.`);
    } else {
      setWorkspaceNotice(`요청 완료 · Route ${result.route}`);
    }

    setAttachments([]);
    setDroppedLinks([]);
    await Promise.all([
      refreshStatus(),
      refreshHistory(selectedProjectId),
      refreshGrowthHistory(),
      refreshCognitiveStatus()
    ]);
  } catch (error) {
    const msg = `요청 처리 실패: ${String(error)}`;
    setMessages((current) => [...current, { role: "assistant", content: msg }]);
    setWorkspaceNotice(msg);
  } finally {
    setBusy(false);
    setStopping(false);
  }
}

  async function stopGeneration() {
    if (!busy || stopping) return;
    setStopping(true);
    setWorkspaceNotice("응답 중지를 요청했습니다.");
    try {
      await invoke<boolean>("cancel_current_request");
    } catch (error) {
      setToolOutput(`응답 중지 실패: ${String(error)}`);
      setStopping(false);
    }
  }

  function newChat() {
    setMessages([{ role: "assistant", content: "새 대화를 시작했습니다." }]);
    setCurrentSessionId(null);
    setReply(null);
    setInput("");
  }

  async function openHistory(item: HistoryItem) {
    if (busy) return;
    try {
      const stored = await invoke<StoredChatMessage[]>("get_chat_messages", {
        sessionId: item.id
      });
      setCurrentSessionId(item.id);
      setMessages(
        stored.length
          ? stored.map((message) => ({ role: message.role, content: message.content }))
          : [{ role: "assistant", content: "이전 대화 내용이 없습니다." }]
      );
      setReply(null);
    } catch (error) {
      setToolOutput(`대화 불러오기 실패: ${String(error)}`);
      setRightTab("Workspace");
    }
  }

  function showHistoryMenu(event: MouseEvent, item: HistoryItem) {
    event.preventDefault();
    event.stopPropagation();
    setContextMenu({
      x: Math.min(event.clientX, window.innerWidth - 238),
      y: Math.min(event.clientY, window.innerHeight - 220),
      item
    });
  }

  function openHistoryAction(mode: Exclude<HistoryActionMode, null>, item: HistoryItem) {
    setContextMenu(null);
    setHistoryActionMode(mode);
    setHistoryActionItem(item);
    setHistoryActionValue(mode === "rename" ? item.title : "");
  }

  function closeHistoryAction() {
    if (historyActionBusy) return;
    setHistoryActionMode(null);
    setHistoryActionItem(null);
    setHistoryActionValue("");
  }

  async function applyHistoryAction(projectId?: string | null) {
    if (!historyActionMode || !historyActionItem || historyActionBusy) return;
    setHistoryActionBusy(true);

    try {
      if (historyActionMode === "rename") {
        const title = historyActionValue.trim();
        if (!title) throw new Error("대화 이름을 입력하세요.");
        await invoke("rename_chat_session", {
          sessionId: historyActionItem.id,
          title
        });
        setWorkspaceNotice(`대화 이름을 "${title}"로 변경했습니다.`);
      }

      if (historyActionMode === "move") {
        await invoke("move_chat_session_to_project", {
          sessionId: historyActionItem.id,
          projectId: projectId ?? null
        });
        const projectName = projectId
          ? projects.find((project) => project.id === projectId)?.name ?? "프로젝트"
          : "프로젝트 없음";
        setWorkspaceNotice(`"${historyActionItem.title}" 대화를 ${projectName}(으)로 이동했습니다.`);
      }

      if (historyActionMode === "delete") {
        await invoke("delete_chat_session", { sessionId: historyActionItem.id });
        if (currentSessionId === historyActionItem.id) newChat();
        setWorkspaceNotice(`"${historyActionItem.title}" 대화를 삭제했습니다.`);
      }

      await refreshHistory(selectedProjectId);
      setRightTab("Workspace");
      closeHistoryAction();
    } catch (error) {
      setToolOutput(`히스토리 작업 실패: ${String(error)}`);
      setWorkspaceNotice("히스토리 작업을 완료하지 못했습니다. Workspace의 오류 내용을 확인하세요.");
      setRightTab("Workspace");
    } finally {
      setHistoryActionBusy(false);
    }
  }

  function showProjectMenu(event: MouseEvent, project: ProjectItem) {
    event.preventDefault();
    event.stopPropagation();
    setContextMenu(null);
    setProjectMenu({
      x: Math.min(event.clientX, window.innerWidth - 235),
      y: Math.min(event.clientY, window.innerHeight - 150),
      project
    });
  }

  async function exportProject(project: ProjectItem) {
    if (projectActionBusy) return;
    setProjectActionBusy(true);
    setProjectMenu(null);

    try {
      const result = await invoke<ProjectExportResult>("export_project", {
        projectId: project.id
      });

      setWorkspaceNotice(`프로젝트 "${result.project_name}"을 내보냈습니다.`);
      setToolOutput(
        [
          `프로젝트 내보내기 완료`,
          `경로: ${result.path}`,
          `대화: ${result.session_count}개`,
          `메시지: ${result.message_count}개`
        ].join("\\n")
      );
      setRightTab("Workspace");
    } catch (error) {
      setWorkspaceNotice(`프로젝트 내보내기 실패: ${String(error)}`);
      setRightTab("Workspace");
    } finally {
      setProjectActionBusy(false);
    }
  }

  async function confirmDeleteProject() {
    if (!projectDeleteTarget || projectActionBusy) return;
    setProjectActionBusy(true);

    try {
      await invoke("delete_project", { projectId: projectDeleteTarget.id });
      if (selectedProjectId === projectDeleteTarget.id) {
        setSelectedProjectId(null);
      }
      setWorkspaceNotice(
        `프로젝트 "${projectDeleteTarget.name}"을 삭제했습니다. 대화는 삭제하지 않고 전체 대화로 이동했습니다.`
      );
      setProjectDeleteTarget(null);
      await Promise.all([refreshProjects(), refreshHistory(null)]);
      setRightTab("Workspace");
    } catch (error) {
      setWorkspaceNotice(`프로젝트 삭제 실패: ${String(error)}`);
      setRightTab("Workspace");
    } finally {
      setProjectActionBusy(false);
    }
  }

  async function createProject() {
    const name = projectName.trim();
    if (!name) return;
    try {
      const created = await invoke<ProjectItem>("create_project", { name });
      setProjectName("");
      setProjectCreateOpen(false);
      await refreshProjects();
      setSelectedProjectId(created.id);
      setWorkspaceNotice(`프로젝트 "${created.name}"을 생성했습니다.`);
    } catch (error) {
      setToolOutput(`프로젝트 생성 실패: ${String(error)}`);
      setRightTab("Workspace");
    }
  }

  async function rateGeneratedImage(imageId: string, rating: number) {
    try {
      const growth = await invoke<ImageGrowthStatus>("rate_image", {
        imageId,
        rating
      });
      setImageGrowth(growth);
      setWorkspaceNotice(`이미지 평가 ${rating}/5가 이미지 성장·개인 선호 학습에 반영되었습니다.`);
      await Promise.all([refreshImageGrowth(), refreshCognitiveStatus()]);
    } catch (error) {
      setWorkspaceNotice(`이미지 평가 저장 실패: ${String(error)}`);
    }
  }

  async function readFile() {
    try {
      const result = await invoke<ToolResult>("read_workspace_file", { relativePath: filePath });
      setToolOutput(`${result.summary}\n\n${result.content ?? ""}`);
    } catch (error) {
      setToolOutput(`파일 읽기 실패: ${String(error)}`);
    }
  }

  async function proposeWrite() {
    try {
      const proposal = await invoke<ApprovalProposal>("propose_file_write", {
        relativePath: filePath,
        content: fileContent
      });
      setApproval(proposal);
      setToolOutput(`승인 필요: ${proposal.summary}`);
      await refreshStatus();
    } catch (error) {
      setToolOutput(`쓰기 제안 실패: ${String(error)}`);
    }
  }

  async function approveWrite() {
    if (!approval) return;
    try {
      const result = await invoke<ToolResult>("approve_file_write", {
        approvalId: approval.approval_id
      });
      setToolOutput(result.summary);
      setApproval(null);
      await refreshStatus();
    } catch (error) {
      setToolOutput(`쓰기 실패: ${String(error)}`);
    }
  }

  async function readWeb() {
    try {
      const result = await invoke<ToolResult>("browser_read", { url });
      setToolOutput(`${result.summary}\n\n${result.content ?? ""}`);
    } catch (error) {
      setToolOutput(`웹 읽기 실패: ${String(error)}`);
    }
  }

  async function toggleSafeMode() {
    const safe = status?.security_state === "SAFE_MODE";
    await invoke(safe ? "exit_safe_mode" : "enter_safe_mode");
    await refreshStatus();
  }

  const stage = reply?.growth_stage ?? status?.growth_stage ?? "능력 측정 중";
  const progress = reply?.growth_progress ?? status?.growth_progress ?? 0;
  const security = reply?.security_state ?? status?.security_state ?? "SECURE";
  const memory = reply?.memory_count ?? status?.memory_count ?? 0;
  const model = reply?.model_status ?? status?.model_status ?? "NOT_CONFIGURED";

  const calibrationText = useMemo(() => {
    if (!status) return "측정 준비";
    if (status.calibration_status === "CALIBRATING") {
      return `측정 중 · ${status.calibration_samples}/5`;
    }
    if (status.calibration_status === "REVIEW_REQUIRED") {
      return "보정 필요";
    }
    return `자동 보정 · 다음 ${status.next_recalibration_in}회 후`;
  }, [status]);

  return (
    <main className="appShell">
      <header className="topBar">
        <div className="brand">METEOR <span>Personal · v2 Phase 5 Candidate</span></div>
        <div className="topStatus">
          <button className="stageBadge" onClick={() => setRightTab("Growth")}>
            {stage} · {progress}%
          </button>
          <span>SECURITY · {security}</span>
          <span>CORE · {busy ? "WORKING" : (reply?.status ?? "READY")}</span>
        </div>
      </header>

      <section className="appGrid">
        <aside className="historyPane">
          <button className="newChat" onClick={newChat}>＋ New Chat</button>

          <div className="sectionHeader">
            <span>Projects</span>
            <button
              className="sectionAdd"
              title="새 프로젝트"
              onClick={() => setProjectCreateOpen((open) => !open)}
            >
              ＋
            </button>
          </div>

          {projectCreateOpen && (
            <div className="projectCreateRow">
              <input
                autoFocus
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void createProject();
                  if (e.key === "Escape") setProjectCreateOpen(false);
                }}
                placeholder="프로젝트 이름"
              />
              <button onClick={() => void createProject()}>생성</button>
            </div>
          )}

          <div className="projectList">
            <button
              className={`projectItem ${selectedProjectId === null ? "active" : ""}`}
              aria-pressed={selectedProjectId === null}
              onClick={() => setSelectedProjectId(null)}
            >
              <span className={`selectionBox ${selectedProjectId === null ? "selected" : ""}`}>
                {selectedProjectId === null ? "✓" : ""}
              </span>
              <span>전체 대화</span>
            </button>

            {projects.map((project) => {
              const selected = selectedProjectId === project.id;
              return (
                <div className={`projectRow ${selected ? "active" : ""}`} key={project.id}>
                  <button
                    className={`projectItem ${selected ? "active" : ""}`}
                    aria-pressed={selected}
                    onClick={() => setSelectedProjectId(project.id)}
                  >
                    <span className={`selectionBox ${selected ? "selected" : ""}`}>
                      {selected ? "✓" : ""}
                    </span>
                    <span>{project.name}</span>
                  </button>
                  <button
                    className="projectMore"
                    title="프로젝트 메뉴"
                    onClick={(event) => showProjectMenu(event, project)}
                  >
                    •••
                  </button>
                </div>
              );
            })}
          </div>

          <div className="historyTitle">History</div>
          <div className="historyList">
            {history.length === 0 && <div className="empty">아직 대화 기록이 없습니다.</div>}
            {history.map((item) => (
              <div
                className={`historyRow ${currentSessionId === item.id ? "active" : ""}`}
                key={item.id}
                onContextMenu={(e) => showHistoryMenu(e, item)}
              >
                <button className="historyItem" onClick={() => void openHistory(item)}>
                  {item.title || "Untitled"}
                </button>
                <button
                  className="historyMore"
                  title="대화 메뉴"
                  onClick={(e) => showHistoryMenu(e, item)}
                >
                  •••
                </button>
              </div>
            ))}
          </div>

          <div className="historyFooter">
            <span>Memory {memory}</span>
            <span>{model}</span>
          </div>
        </aside>

        <section className="chatPane">
          <div className="chatHeader">
            <div>
              <strong>METEOR</strong>
              <span>{calibrationText}</span>
            </div>
            <span className="trace">
              {busy ? `응답 생성 중 · ${elapsed}초` : (reply?.trace_id ? `Trace ${reply.trace_id.slice(0, 8)}` : "")}
            </span>
          </div>

          <div className="messageStream">
            {messages.map((message, index) => (
              <div className={`messageRow ${message.role}`} key={`${message.role}-${index}`}>
                <div className="messageBubble">
                  {message.content.split(/(https?:\/\/[^\s]+)/g).map((part, partIndex) =>
                    /^https?:\/\//.test(part) ? (
                      <a
                        key={partIndex}
                        className="chatLink"
                        href={part}
                        target="_blank"
                        rel="noreferrer"
                      >
                        {part}
                      </a>
                    ) : (
                      <span key={partIndex}>{part}</span>
                    )
                  )}
                </div>

                {message.role === "assistant" && message.sources && message.sources.length > 0 && (
                  <div className="sourceCards">
                    {message.sources.slice(0, 6).map((source) => (
                      <a
                        key={`${source.index}-${source.url}`}
                        className="sourceCard"
                        href={source.url}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <strong>[{source.index}] {source.title}</strong>
                        <span>{source.domain}{source.published_at ? ` · ${source.published_at}` : ""}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          <form
            className={`composer ${dragActive ? "dragActive" : ""}`}
            onSubmit={submit}
            onDragOver={(event) => {
              event.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
          >
            {(attachments.length > 0 || droppedLinks.length > 0) && (
              <div className="attachmentTray">
                {attachments.map((item) => (
                  <div className="attachmentChip" key={item.id}>
                    <img src={convertFileSrc(item.path)} alt={item.name} />
                    <span>{item.name}</span>
                    <button type="button" onClick={() => removeAttachment(item.id)}>×</button>
                  </div>
                ))}
                {droppedLinks.map((link) => (
                  <div className="linkChip" key={link}>
                    <span>🔗 {link}</span>
                    <button type="button" onClick={() => removeDroppedLink(link)}>×</button>
                  </div>
                ))}
              </div>
            )}

            <div className="composerRow">
              <label className="attachButton" title="이미지 첨부">
                ＋
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  multiple
                  hidden
                  onChange={(event) => {
                    if (event.target.files) void addImageFiles(event.target.files);
                    event.target.value = "";
                  }}
                />
              </label>

              <button
                type="button"
                className={`webGroundButton ${webMode === "ON" ? "active" : ""}`}
                title="최신 웹 정보 확인"
                onClick={() => setWebMode((mode) => mode === "AUTO" ? "ON" : "AUTO")}
              >
                🌐 {webMode === "ON" ? "웹 확인" : "자동"}
              </button>

              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onPaste={handlePaste}
                placeholder="메시지 · 링크 또는 이미지를 드래그해 첨부"
              />

              {busy ? (
                <button
                  type="button"
                  className="stopButton"
                  onClick={() => void stopGeneration()}
                  disabled={stopping}
                >
                  {stopping ? "중지 중…" : `중지 · ${elapsed}초`}
                </button>
              ) : (
                <button type="submit">Send</button>
              )}
            </div>

            {dragActive && (
              <div className="dropOverlay">이미지 또는 링크를 여기에 놓으세요</div>
            )}
          </form>
        </section>

        <aside className="rightPane">
          <div className="tabBar">
            {(["Updates", "Library", "Workspace", "Context", "Growth", "Models"] as RightTab[]).map((tab) => (
              <button
                key={tab}
                className={rightTab === tab ? "active" : ""}
                onClick={() => setRightTab(tab)}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="rightContent">

{rightTab === "Updates" && (
  <>
    <h2>Updates</h2>
    <p className="muted">
      METEOR는 서명된 HTTPS 업데이트만 받아들이고, 검증 실패 시 Autopilot이 자동 롤백합니다.
    </p>
    <div className="updateCenterCard">
      <div className="taskHeader">
        <strong>Signed Update Channel</strong>
        <span>{remoteUpdateStatus?.configured ? "CONNECTED" : "PUBLISHER NOT CONNECTED"}</span>
      </div>
      <div className="updateCenterGrid">
        <div><span>Current</span><strong>{remoteUpdateStatus?.current_version ?? "..."}</strong></div>
        <div><span>Signature</span><strong>{remoteUpdateStatus?.signature_required ? "REQUIRED" : "OFF"}</strong></div>
        <div><span>Publisher Key</span><strong>{remoteUpdateStatus?.publisher_key_ready ? "READY" : "MISSING"}</strong></div>
        <div><span>Auto Check</span><strong>{remoteUpdateStatus?.auto_check ? "ON" : "OFF"}</strong></div>
        <div><span>Auto Download</span><strong>{remoteUpdateStatus?.auto_download ? "ON" : "OFF"}</strong></div>
        <div><span>Apply</span><strong>{remoteUpdateStatus?.apply_requires_approval ? "1× APPROVAL" : "AUTO"}</strong></div>
      </div>
      <div className="narrativeImportActions">
        <button disabled={remoteUpdateBusy} onClick={() => void checkRemoteUpdate()}>업데이트 확인</button>
        <button className="primaryAction" disabled={remoteUpdateBusy || !remoteUpdateCheck?.update_available}
          onClick={() => void applyRemoteUpdate()}>업데이트 적용</button>
      </div>
      <div className="narrativeNoticeCard">
        <strong>{remoteUpdateBusy ? "처리 중" : "상태"}</strong>
        <p>{remoteUpdateNotice}</p>
      </div>
      {!remoteUpdateStatus?.configured && (
        <div className="narrativePolicyHint">
          <strong>Publisher endpoint 준비 중</strong>
          <span>공개키 서명 검증 코어는 설치됩니다.</span>
          <small>영구 HTTPS publisher 주소를 한 번 연결하면 이후 자동 다운로드가 활성화됩니다.</small>
        </div>
      )}
    </div>
  </>
)}

{rightTab === "Library" && (
  <>
    <h2>Narrative Library</h2>
    <p className="muted">
      내 작품과 개인 연구자료를 로컬에서 관리합니다. 개인 연구 원문은 외부 AI로 전송되지 않습니다.
    </p>

    <div className="narrativeImportActions">
      <button
        className="primaryAction"
        disabled={narrativeImportBusy}
        onClick={() => void importNarrativeDocument("OWNED")}
      >
        + 내 작품
      </button>
      <button
        disabled={narrativeImportBusy}
        onClick={() => void importNarrativeDocument("PERSONAL_RESEARCH")}
      >
        + 개인 연구자료
      </button>
    </div>

    <div className="narrativeNoticeCard">
      <strong>{narrativeImportBusy ? "처리 중" : "Library 상태"}</strong>
      <p>{narrativeNotice}</p>
    </div>

    <div className="narrativeStructureCard">
      <div className="taskHeader">
        <strong>N3 Structure Engine</strong>
        <span>{narrativeStructure?.stage ?? "N3_FOUNDATION"}</span>
      </div>
      <div className="narrativeMetricGrid">
        <div><span>Chapters</span><strong>{narrativeStructure?.chapter_count ?? 0}</strong></div>
        <div><span>Scenes</span><strong>{narrativeStructure?.scene_count ?? 0}</strong></div>
        <div><span>Characters</span><strong>{narrativeStructure?.character_count ?? 0}</strong></div>
        <div><span>Events</span><strong>{narrativeStructure?.event_count ?? 0}</strong></div>
        <div><span>Foreshadows</span><strong>{narrativeStructure?.foreshadow_count ?? 0}</strong></div>
        <div><span>Payoffs</span><strong>{narrativeStructure?.payoff_count ?? 0}</strong></div>
      </div>
      <small>현재는 장/장면 구조 기반입니다. 인물·사건·복선 의미 분석은 다음 N3 Semantic Parser에서 채워집니다.</small>
    </div>

    <div className="narrativeLibraryList">
      {narrativeLibrary.length === 0 ? (
        <div className="narrativeEmpty">
          아직 등록된 작품이 없습니다. 앱에서 바로 자료를 추가할 수 있습니다.
        </div>
      ) : (
        narrativeLibrary.map((item) => (
          <div className="narrativeBookRow" key={item.work_id}>
            <div>
              <strong>{item.title}</strong>
              <span>{item.corpus_tier.replaceAll("_", " ")}</span>
            </div>
            <small>{item.local_only ? "LOCAL ONLY" : "Production"}</small>
          </div>
        ))
      )}
    </div>

    <div className="narrativePolicyHint">
      <strong>Rights boundary</strong>
      <span>BLUE OWNED → Production · AMBER PERSONAL RESEARCH → LOCAL ONLY</span>
      <small>DRM/캡처방지 우회 및 권리 불명 자료의 자동 수집은 지원하지 않습니다.</small>
    </div>
  </>
)}

            {rightTab === "Workspace" && (
              <>
                <h2>Workspace</h2>
                <p className="muted">현재 작업, 웹 근거, 도구 상태와 승인 요청을 확인합니다.</p>
                <div className="groundingPolicyCard">
                  <strong>Freshness Router</strong>
                  <span>오늘·최근·현재·뉴스 같은 질문은 자동으로 최신 웹 근거를 확인합니다.</span>
                  <small>🌐 웹 확인을 켜면 일반 질문도 강제로 최신 뉴스 검색을 수행합니다.</small>
                </div>

                <div className="workspaceStatusCard">
                  <strong>최근 상태</strong>
                  <p>{workspaceNotice}</p>
                </div>

                {imageTask && (
                  <div className={`imageTaskCard ${imageTask.status === "NOT_CONFIGURED" ? "warning" : ""}`}>
                    <div className="taskHeader">
                      <strong>이미지 생성 요청</strong>
                      <span>{imageTask.status === "NOT_CONFIGURED" ? "엔진 미연결" : "확인 필요"}</span>
                    </div>
                    <p>{imageTask.prompt}</p>
                    <ul>
                      {imageTask.defaults.map((value) => <li key={value}>{value}</li>)}
                    </ul>
                    <small>{imageCapability?.message}</small>
                  </div>
                )}


{imageBusy && (
  <div className="imageGeneratingCard">
    <strong>이미지 생성 중 · {imageElapsed}초</strong>
    <p>전용 이미지 엔진을 사용 중입니다. 완료되면 결과가 이 Workspace에 표시됩니다.</p>
  </div>
)}

{lastImage && (
  <div className="generatedImageCard">
    <img src={convertFileSrc(lastImage.path)} alt={lastImage.prompt} />
    <div className="generatedImageMeta">
      <strong>{lastImage.model}</strong>
      <span>
        {lastImage.mode || "FAST"} · {lastImage.profile || "default"} ·
        {" "}{lastImage.width}×{lastImage.height} · {(lastImage.elapsed_ms / 1000).toFixed(1)}초
      </span>
    </div>
    <p>{lastImage.prompt}</p>
    <div className="imageRating">
      <span>결과 평가 · 개인 이미지 선호 학습</span>
      {[1,2,3,4,5].map((rating) => (
        <button key={rating} onClick={() => void rateGeneratedImage(lastImage.image_id, rating)}>
          {rating}
        </button>
      ))}
    </div>
  </div>
)}

{videoPlan && (
  <div className="videoPlanCard">
    <div className="taskHeader">
      <strong>영상 작업</strong>
      <span>{videoBusy ? "생성 중" : (lastVideo ? "완료" : (videoStatus?.status ?? "대기"))}</span>
    </div>
    <p>{videoPlan.summary}</p>
    <dl>
      <dt>Mode</dt><dd>{videoPlan.mode}</dd>
      <dt>Duration</dt><dd>{videoPlan.duration_seconds}초</dd>
      <dt>Ratio</dt><dd>{videoPlan.aspect_ratio}</dd>
      <dt>Motion</dt><dd>{videoPlan.motion}</dd>
      <dt>Camera</dt><dd>{videoPlan.camera}</dd>
      <dt>Engine</dt><dd>{videoStatus?.active_model_hint ?? "LTX local"}</dd>
    </dl>
    {videoBusy && <small>Apple Silicon 로컬 영상 생성은 시간이 오래 걸릴 수 있습니다.</small>}
  </div>
)}

{lastVideo && (
  <div className="generatedVideoCard">
    <video controls src={convertFileSrc(lastVideo.video_path)} />
    <div className="generatedImageMeta">
      <strong>{lastVideo.model_hint}</strong>
      <span>{lastVideo.resolution} · {lastVideo.duration_seconds}초 · {(lastVideo.elapsed_ms / 1000).toFixed(1)}초</span>
    </div>
    <div className="imageRating">
      <span>영상 결과 평가 · 개인 영상 선호 학습</span>
      {[1,2,3,4,5].map((rating) => (
        <button key={rating} onClick={() => void rateVideo(rating)}>
          {rating}
        </button>
      ))}
    </div>
  </div>
)}

{lastRoute && (
  <div className="routerStatusCard">
    <strong>Intelligence Router</strong>
    <span>{lastRoute.intent} · 신뢰 {(lastRoute.confidence * 100).toFixed(0)}%</span>
    <small>{lastRoute.reason}</small>
  </div>
)}

                {approval && (
                  <div className="approval">
                    <strong>METEOR·APPROVAL</strong>
                    <p>{approval.summary}</p>
                    <small>Risk {approval.risk_level} · Reversible {String(approval.reversible)}</small>
                    <button onClick={approveWrite}>이번 한 번 승인</button>
                  </div>
                )}

                <pre>{toolOutput}</pre>
              </>
            )}


            {rightTab === "Images" && (
              <>
                <h2>Images</h2>
                <p className="muted">Local Image Engine · FLUX.2 [klein] 4B</p>

                <div className="imageEngineStatus">
                  <div><span>Engine</span><strong>{imageCapability?.status ?? "UNKNOWN"}</strong></div>
                  <div><span>Model</span><strong>{imageCapability?.active_model || "FLUX.2 [klein] 4B"}</strong></div>
                  <div><span>Device</span><strong>{imageCapability?.device ?? "mps"}</strong></div>
                </div>

                {imageBusy && (
                  <div className="imageGeneratingCard">
                    <strong>이미지 생성 중 · {imageElapsed}초</strong>
                    <p>Apple Silicon Metal을 사용합니다. 메모리 확보를 위해 대화 모델은 잠시 전환될 수 있습니다.</p>
                  </div>
                )}

                {lastImage && (
                  <div className="generatedImageCard">
                    <img src={convertFileSrc(lastImage.path)} alt={lastImage.prompt} />
                    <div className="generatedImageMeta">
                      <strong>{lastImage.model}</strong>
                      <span>{lastImage.width}×{lastImage.height} · {(lastImage.elapsed_ms / 1000).toFixed(1)}초</span>
                    </div>
                    <p>{lastImage.prompt}</p>
                    <div className="imageRating">
                      <span>결과 평가</span>
                      {[1,2,3,4,5].map((rating) => (
                        <button key={rating} onClick={() => void rateGeneratedImage(lastImage.image_id, rating)}>
                          {rating}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="imageGrowthCard">
                  <div className="growthHero">
                    <strong>이미지 · {imageGrowth?.stage ?? "사원"}</strong>
                    <span>{imageGrowth?.progress_percent ?? 0}%</span>
                  </div>
                  <div className="progress"><span style={{ width: `${imageGrowth?.progress_percent ?? 0}%` }} /></div>
                  <dl>
                    <dt>생성 성공</dt><dd>{imageGrowth?.successful_generations ?? 0}</dd>
                    <dt>평가 결과</dt><dd>{imageGrowth?.rated_generations ?? 0}</dd>
                    <dt>평균 평가</dt><dd>{(imageGrowth?.average_rating ?? 0).toFixed(2)} / 5</dd>
                  </dl>
                  <small>성장은 생성 경험·사용자 평가·향후 모델 벤치마크를 기반으로 합니다. 모델 가중치를 몰래 변경하지 않습니다.</small>
                </div>

                <div className="imageHistoryPanel">
                  <strong>최근 이미지</strong>
                  {imageHistory.length === 0 && <p className="muted">아직 생성 기록이 없습니다.</p>}
                  {imageHistory.map((image) => (
                    <button
                      key={image.image_id}
                      className="imageHistoryRow"
                      onClick={() => setLastImage({
                        image_id: image.image_id,
                        path: image.path,
                        prompt: image.prompt,
                        model: image.model,
                        seed: 0,
                        width: 1024,
                        height: 1024,
                        elapsed_ms: image.elapsed_ms,
                        mode: "FAST",
                        profile: "LEGACY_HISTORY",
                        reference_count: 0,
                        steps: 0,
                        guidance_scale: 0
                      })}
                    >
                      <span>{image.prompt}</span>
                      <small>{image.rating ? `${image.rating}/5` : "미평가"}</small>
                    </button>
                  ))}
                </div>
              </>
            )}

            {rightTab === "Browser" && (
              <>
                <h2>Browser · Read only</h2>
                <input value={url} onChange={(e) => setUrl(e.target.value)} />
                <button className="wide" onClick={readWeb}>Read URL</button>
                <pre>{toolOutput}</pre>
              </>
            )}

            {rightTab === "Files" && (
              <>
                <h2>Files · METEOR Workspace</h2>
                <input value={filePath} onChange={(e) => setFilePath(e.target.value)} />
                <textarea value={fileContent} onChange={(e) => setFileContent(e.target.value)} />
                <div className="row">
                  <button onClick={readFile}>Read</button>
                  <button onClick={proposeWrite}>Propose Write</button>
                </div>
                {approval && (
                  <div className="approval">
                    <strong>승인 대기</strong>
                    <p>{approval.summary}</p>
                    <button onClick={approveWrite}>이번 한 번 승인</button>
                  </div>
                )}
              </>
            )}


{rightTab === "Context" && (
  <>
    <h2>Context</h2>
    <p className="muted">현재 대화에 실제로 반영되는 메모리·개인화 학습·첨부 상태를 확인합니다.</p>

    <div className="cognitiveCard">
      <div className="taskHeader">
        <strong>Personal Cognitive Learning</strong>
        <span>{cognitiveStatus ? "ACTIVE" : "READY"}</span>
      </div>
      <dl>
        <dt>인지 에피소드</dt><dd>{cognitiveStatus?.episode_count ?? 0}</dd>
        <dt>선호 패턴</dt><dd>{cognitiveStatus?.preference_count ?? 0}</dd>
        <dt>가져온 대화</dt><dd>{cognitiveStatus?.imported_conversations ?? 0}</dd>
        <dt>분석 메시지</dt><dd>{cognitiveStatus?.imported_messages ?? 0}</dd>
        <dt>미디어 평가</dt><dd>{cognitiveStatus?.media_feedback_count ?? 0}</dd>
      </dl>

      <label className={`historyImportButton ${cognitiveImportBusy ? "disabled" : ""}`}>
        {cognitiveImportBusy ? "분석 중…" : "ChatGPT conversations.json 가져오기"}
        <input
          type="file"
          accept=".json,application/json"
          disabled={cognitiveImportBusy}
          onChange={(event) => void importChatGptHistory(event)}
        />
      </label>

      <small>
        원문을 모델에 그대로 재학습하지 않고, 관찰 가능한 수정·선택·결과에서 관련 에피소드와 선호를 추출합니다.
      </small>

      {lastImportReport && (
        <div className="importReport">
          <strong>최근 가져오기</strong>
          <span>대화 {lastImportReport.conversations_seen} · 메시지 {lastImportReport.messages_seen}</span>
          <span>에피소드 {lastImportReport.episodes_created} · 선호 업데이트 {lastImportReport.preferences_updated}</span>
          <span>민감정보 제외 {lastImportReport.skipped_sensitive}</span>
        </div>
      )}

      {(cognitiveStatus?.top_preferences.length ?? 0) > 0 && (
        <div className="preferenceList">
          <strong>관찰된 선호</strong>
          {cognitiveStatus?.top_preferences.slice(0, 6).map((pref) => (
            <div key={pref.key} className="preferenceRow">
              <span>{pref.label}</span>
              <small>{pref.category} · 근거 {pref.evidence_count}회 · {(pref.confidence * 100).toFixed(0)}%</small>
            </div>
          ))}
        </div>
      )}
    </div>

    <dl>
      <dt>Memory</dt><dd>{memory}</dd>
      <dt>Model</dt><dd>{model}</dd>
      <dt>Local AI</dt><dd>Qwen3.5 35B-A3B</dd>
      <dt>Growth</dt><dd>{stage} · {progress}%</dd>
      <dt>Calibration</dt><dd>{calibrationText}</dd>
      <dt>Image</dt><dd>{imageCapability?.status ?? "UNKNOWN"} · {imageGrowth?.stage ?? "사원"}</dd>
      <dt>Web</dt><dd>{webMode === "ON" ? "FORCED" : "AUTO"}</dd>
      <dt>Attachments</dt><dd>{attachments.length}</dd>
      <dt>Pending</dt><dd>{status?.pending_approvals ?? 0}</dd>
    </dl>

    <div className="compactSecurityCard">
      <div>
        <strong>보안 · {security === "SAFE_MODE" ? "강화" : "기본"}</strong>
        <small>강화 모드는 Side Effect 작업을 더 보수적으로 제한합니다.</small>
      </div>
      <button onClick={() => void toggleSafeMode()}>
        {security === "SAFE_MODE" ? "기본으로" : "강화"}
      </button>
    </div>
  </>
)}

{rightTab === "Growth" && (
  <>
    <h2>Growth</h2>

    <div className="growthHero">
      <strong>{verifiedGrowth?.stage ?? "능력 측정 중"}</strong>
      <span>
        {verifiedGrowth?.calibrated
          ? `${verifiedGrowth.progress_percent}%`
          : "Calibration"}
      </span>
    </div>

    <div className="progress">
      <span style={{ width: `${verifiedGrowth?.calibrated ? verifiedGrowth.progress_percent : 0}%` }} />
    </div>

    <p className="muted">
      {verifiedGrowth?.note ?? "v2 검증 벤치마크를 실행하면 실제 측정 결과만 Growth에 반영됩니다."}
    </p>

    {verifiedGrowth?.calibrated && (
      <div className="verifiedGrowthCard">
        <div><span>METEOR Benchmark</span><strong>{verifiedGrowth.score_percent?.toFixed(1) ?? "-"}%</strong></div>
        <div><span>Passed</span><strong>{verifiedGrowth.passed}/{verifiedGrowth.total}</strong></div>
        <div><span>Factual</span><strong>{verifiedGrowth.factual_accuracy?.toFixed(1) ?? "-"}%</strong></div>
        <div><span>Reasoning</span><strong>{verifiedGrowth.reasoning_quality?.toFixed(1) ?? "-"}%</strong></div>
        <div><span>Instruction</span><strong>{verifiedGrowth.instruction_following?.toFixed(1) ?? "-"}%</strong></div>
        <div><span>Safety</span><strong>{verifiedGrowth.safety_correctness?.toFixed(1) ?? "-"}%</strong></div>
      </div>
    )}

    <p className="muted">
      등급은 능력을 만들어내는 값이 아니라, 실제 벤치마크 향상이 확인된 뒤 그 결과를 표시합니다.
    </p>
    <p className="muted">모델명은 참고 Anchor이며 절대 서열이 아닙니다.</p>

    <div className="stageGrid">
      {growthStages.map((item) => (
        <span
          className={item.name === verifiedGrowth?.stage ? "activeStage" : ""}
          key={item.name}
        >
          {item.name}<small> ({item.models})</small>
        </span>
      ))}
    </div>

    <div className="growthHistorySection">
      <div className="growthHistoryHeader">
        <strong>성장 히스토리</strong>
        <button onClick={() => void Promise.all([refreshGrowthHistory(), refreshVerifiedGrowth()])}>새로고침</button>
      </div>

      {verifiedGrowth?.improvements?.map((item, index) => (
        <div className="verifiedImprovement" key={`${item}-${index}`}>✓ {item}</div>
      ))}

      {growthHistory.length === 0 && (
        <div className="emptyGrowthHistory">아직 기존 등급 변경 기록이 없습니다.</div>
      )}

      {growthHistory.map((event) => (
        <button
          className="growthHistoryItem"
          key={event.id}
          onClick={() => setSelectedGrowthEvent(event)}
        >
          <div>
            <strong>{event.to_stage}</strong>
            <span>{event.summary}</span>
          </div>
          <small>{new Date(event.created_at_ms).toLocaleString()}</small>
        </button>
      ))}
    </div>
  </>
)}

{rightTab === "Models" && (
  <>
    <h2>Models & Updates</h2>
    <p className="muted">현재 모델·미디어 엔진·Skill Evolution·승인 기반 업데이트 상태를 확인합니다.</p>

    <dl>
      <dt>Text</dt><dd>Qwen3.5-35B-A3B Q8_0</dd>
      <dt>Runtime</dt><dd>{model}</dd>
      <dt>Image</dt><dd>{imageCapability?.active_model || "FLUX.2 [klein] 4B"}</dd>
      <dt>Image v2</dt><dd>{imageCapability?.version ?? "unknown"}</dd>
      <dt>Quality</dt><dd>{imageCapability?.quality_model_installed ? "READY" : "OPTIONAL"}</dd>
      <dt>Video</dt><dd>{videoStatus?.active_model_hint ?? "LTX local candidate"}</dd>
      <dt>Video state</dt><dd>{videoStatus?.status ?? "UNKNOWN"}</dd>
    </dl>

    <div className="modelInfoCard">
      <strong>Image Runtime v2</strong>
      <span>
        {(imageCapability?.capabilities ?? []).length > 0
          ? imageCapability?.capabilities.join(" · ")
          : "FAST · EDIT · REFERENCE · QUALITY 준비"}
      </span>
      <small>
        QUALITY는 FLUX.2 [klein] Base 4B가 설치된 경우 사용합니다. 없으면 FAST로 명확히 fallback합니다.
      </small>
    </div>

    <div className="modelInfoCard">
      <strong>Local Video Runtime</strong>
      <span>{videoStatus?.local_candidate ?? "LTX 2.5 Fast"}</span>
      <small>{videoStatus?.note ?? "SETUP_LTX_VIDEO_RUNTIME.command로 준비할 수 있습니다."}</small>
    </div>

    <div className="modelInfoCard">
      <strong>Skill Evolution</strong>
      <span>{skillEvolution?.auto_stage_enabled ? "Trusted auto-stage 준비됨" : "Registry 미설정"}</span>
      <small>{skillEvolution?.note ?? "신뢰된 GitHub Skill 후보만 Sandbox에 자동 스테이징합니다."}</small>
    </div>

    <div className="trustedUpdateCard">
      <div className="taskHeader">
        <strong>Trusted Update Manager</strong>
        <span>{updateStatus?.pending_packages ?? 0} package</span>
      </div>
      <p>{updateStatus?.policy ?? "업데이트별 1회 승인 후 설치·검증·롤백"}</p>
      <div className="updateActions">
        <button onClick={() => void openUpdateInbox()}>Inbox 열기</button>
        <button onClick={() => void scanUpdateInbox()} disabled={updateBusy}>
          {updateBusy ? "검사 중…" : "업데이트 후보 검사"}
        </button>
      </div>

      {updateProposal && (
        <div className="updateProposal">
          <strong>{updateProposal.title} · {updateProposal.version}</strong>
          <span>
            Risk {updateProposal.risk_level} · 파일 {updateProposal.verified_files}개 검증 ·
            {" "}Rollback {updateProposal.reversible ? "가능" : "불가"}
          </span>
          <ul>
            {updateProposal.changes.slice(0, 8).map((change) => <li key={change}>{change}</li>)}
          </ul>
          <small>
            외부 전송 {updateProposal.external_transfer ? "있음" : "없음"} ·
            권한: {updateProposal.permissions.join(", ")}
          </small>
          <button
            className="primaryAction"
            disabled={updateBusy || !updateProposal.reversible || updateProposal.external_transfer}
            onClick={() => void approveTrustedUpdate()}
          >
            이번 업데이트 1회 승인 · 설치
          </button>
        </div>
      )}
    </div>
  </>
)}
            {rightTab === "Security" && (
              <>
                <h2>Security</h2>
                <div className="securityHero">{security}</div>
                <p className="muted">
                  Safe Mode에서는 파일 쓰기 등 Side Effect 작업을 차단합니다.
                </p>
                <button className="wide" onClick={toggleSafeMode}>
                  {security === "SAFE_MODE" ? "Exit Safe Mode" : "Enter Safe Mode"}
                </button>
              </>
            )}
          </div>
        </aside>
      </section>

      {projectMenu && (
        <div
          className="historyContextMenu projectContextMenu"
          style={{ left: projectMenu.x, top: projectMenu.y }}
          onClick={(event) => event.stopPropagation()}
        >
          <button onClick={() => void exportProject(projectMenu.project)}>⇩ 내보내기</button>
          <div className="contextDivider" />
          <button
            className="danger"
            onClick={() => {
              setProjectDeleteTarget(projectMenu.project);
              setProjectMenu(null);
            }}
          >
            ⌫ 삭제
          </button>
        </div>
      )}

      {projectDeleteTarget && (
        <div className="modalBackdrop" onClick={() => !projectActionBusy && setProjectDeleteTarget(null)}>
          <div className="actionModal" onClick={(event) => event.stopPropagation()}>
            <h3>프로젝트 삭제</h3>
            <p>"{projectDeleteTarget.name}" 프로젝트를 삭제할까요?</p>
            <p className="muted">
              프로젝트만 삭제합니다. 포함된 대화는 삭제하지 않고 전체 대화로 이동합니다.
            </p>
            <div className="modalActions">
              <button onClick={() => setProjectDeleteTarget(null)} disabled={projectActionBusy}>취소</button>
              <button className="dangerAction" onClick={() => void confirmDeleteProject()} disabled={projectActionBusy}>
                삭제
              </button>
            </div>
          </div>
        </div>
      )}

      {contextMenu && (
        <div
          className="historyContextMenu"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <button onClick={() => openHistoryAction("rename", contextMenu.item)}>✎ 이름 변경</button>
          <button onClick={() => openHistoryAction("move", contextMenu.item)}>▣ 프로젝트로 이동</button>
          <div className="contextDivider" />
          <button className="danger" onClick={() => openHistoryAction("delete", contextMenu.item)}>⌫ 삭제</button>
        </div>
      )}

      {historyActionMode && historyActionItem && (
        <div className="modalBackdrop" onClick={closeHistoryAction}>
          <div className="actionModal" onClick={(e) => e.stopPropagation()}>
            {historyActionMode === "rename" && (
              <>
                <h3>대화 이름 변경</h3>
                <input
                  autoFocus
                  value={historyActionValue}
                  onChange={(e) => setHistoryActionValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") void applyHistoryAction();
                    if (e.key === "Escape") closeHistoryAction();
                  }}
                />
                <div className="modalActions">
                  <button onClick={closeHistoryAction}>취소</button>
                  <button className="primaryAction" onClick={() => void applyHistoryAction()} disabled={historyActionBusy}>
                    변경
                  </button>
                </div>
              </>
            )}

            {historyActionMode === "move" && (
              <>
                <h3>프로젝트로 이동</h3>
                <p className="muted">"{historyActionItem.title}" 대화를 이동할 위치를 선택하세요.</p>
                <div className="moveProjectChoices">
                  <button onClick={() => void applyHistoryAction(null)} disabled={historyActionBusy}>
                    프로젝트 없음
                  </button>
                  {projects.map((project) => (
                    <button
                      key={project.id}
                      onClick={() => void applyHistoryAction(project.id)}
                      disabled={historyActionBusy}
                    >
                      {project.name}
                    </button>
                  ))}
                </div>
                <div className="modalActions">
                  <button onClick={closeHistoryAction}>취소</button>
                </div>
              </>
            )}

            {historyActionMode === "delete" && (
              <>
                <h3>대화 삭제</h3>
                <p>"{historyActionItem.title}" 대화를 삭제합니다.</p>
                <p className="muted">연결된 세션 메모리는 삭제 상태로 전환됩니다.</p>
                <div className="modalActions">
                  <button onClick={closeHistoryAction}>취소</button>
                  <button className="dangerAction" onClick={() => void applyHistoryAction()} disabled={historyActionBusy}>
                    삭제
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {selectedGrowthEvent && (
        <div className="modalBackdrop" onClick={() => setSelectedGrowthEvent(null)}>
          <div className="actionModal growthDetailModal" onClick={(e) => e.stopPropagation()}>
            <h3>{selectedGrowthEvent.summary}</h3>
            <div className="growthTransition">
              <span>{selectedGrowthEvent.from_stage}</span>
              <strong>→</strong>
              <span>{selectedGrowthEvent.to_stage}</span>
            </div>
            <ul>
              {selectedGrowthEvent.details.map((detail) => <li key={detail}>{detail}</li>)}
            </ul>
            <dl>
              <dt>성공 작업</dt><dd>{selectedGrowthEvent.successful_actions}</dd>
              <dt>신뢰도</dt><dd>{selectedGrowthEvent.confidence_percent}%</dd>
              <dt>기록 시각</dt><dd>{new Date(selectedGrowthEvent.created_at_ms).toLocaleString()}</dd>
            </dl>
            <div className="modalActions">
              <button className="primaryAction" onClick={() => setSelectedGrowthEvent(null)}>닫기</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
